package org.jsp.jsp_gram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JspGramApplicationTests {

	@Test
	void contextLoads() {
	}

}
